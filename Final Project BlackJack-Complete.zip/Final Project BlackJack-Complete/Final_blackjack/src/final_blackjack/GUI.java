package final_blackjack;


import javax.swing.*;
import java.util.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class GUI extends JFrame {
    
    //TO DO: Make a start screen, load and save screen, and play-game screen.
    //if there exists a saved game, can load from json file.
    //On start screen, there will be a "Load the game, or start game"
    //On the gameplay screen, 
    //actual window resolution
    int aW = 1280;
    int aH = 800;
    
    //Color for UI
        //background colors
        Color bgroundColor = new Color(36, 99, 75);
        
        //Button colors
        Color btnColor = new Color(77, 184, 255);
        
        //Button Fonts
        Font btnFont = new Font("Times New Roman", Font.PLAIN, 24);
    
    //buttons
    JButton btnHit = new JButton();
    JButton btnStand = new JButton();
    JButton btnBet = new JButton();
    JButton btnSave = new JButton();
    JButton btnRestart = new JButton();
    JButton btnExit = new JButton();
    
    //Grids
    int gridX = 50;
    int gridY = 50;
    int gridW = 900;
    int gridH = 300;
    
    //totals and hit-stand grid.  Effects Right rect
    int hsX = gridX + gridW + 50;
    int hsY = gridY;
    int hsW = 250;
    int hsH = 300;
    
    public GUI() {
        this.setSize(aW+7, aH+29);
        this.setTitle("BlackJack");
        this.setVisible(true);
        this.setResizable(false);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Board board = new Board();
        this.setContentPane(board);
        this.setLayout(null);
        
        //Hit Button
        ActHit aHit = new ActHit();
        btnHit.addActionListener(aHit);
        btnHit.setBackground(btnColor);
        btnHit.setBounds(260, 400, 100, 60);
        btnHit.setText("HIT");
        btnHit.setFont(btnFont);
        board.add(btnHit);
        
        //Stand Button
        ActStand aStand = new ActStand();
        btnStand.addActionListener(aStand);
        btnStand.setBackground(btnColor);
        btnStand.setBounds(380, 400, 200, 60);
        btnStand.setText("STAND");
        btnStand.setFont(btnFont);
        board.add(btnStand);

        //Bet Button
        ActBet aBet = new ActBet();
        btnBet.addActionListener(aBet);
        btnBet.setBackground(btnColor);
        btnBet.setBounds(140, 400, 100, 60);
        btnBet.setText("BET");
        btnBet.setFont(btnFont);
        board.add(btnBet);
        
        //Save Button
        ActSave aSave = new ActSave();
        btnSave.addActionListener(aSave);
        btnSave.setBackground(btnColor);
        btnSave.setBounds(820, 400, 100, 60);
        btnSave.setText("Save");
        btnSave.setFont(btnFont);
        board.add(btnSave);
        
        //Replay Button
        ActRestart aRestart= new ActRestart();
        btnRestart.addActionListener(aRestart);
        btnRestart.setBackground(btnColor);
        btnRestart.setBounds(600, 400, 200, 60);
        btnRestart.setText("RESTART?");
        btnRestart.setFont(btnFont);
        board.add(btnRestart);
        
        //Exit Button
        ActExit aExit = new ActExit();
        btnExit.addActionListener(aExit);
        btnExit.setBackground(btnColor);
        btnExit.setBounds(60, 400, 100, 60);
        btnExit.setText("QUIT");
        btnExit.setFont(btnFont);
        board.add(btnExit);
    }
    
    public class Board extends JPanel {
        
        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setColor(bgroundColor);
            g.fillRect(0, 0, aW, aH);
            
            // temp Grid
            g.setColor(Color.orange);
            g.drawRect(gridX, gridY, gridW, gridH);
            
            //temp grid borders, Bottom Rect
            g.drawRect(gridX, gridY + gridH + 50, gridW, 300);
            
            //temp totals
            g.drawRect(hsX, hsY, hsW, hsH);
            
//background image
        
        
        }
    }
    
    public class ActHit implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("You have chosen to: HIT");
            
        }
        
    }
    
    public class ActStand implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("You have chosen to: STAND");
            
        }
        
    }
    
    public class ActBet implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("You have placed your Bet");
            
        }
        
    }
    
     public class ActSave implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Game Saved");
            
        }
        
    }
    public class ActExit implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Goodbye!");
            
        }
        
    }
    
    public class ActRestart implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.println("Restarting Game");
            
        }
        
    }
 }


