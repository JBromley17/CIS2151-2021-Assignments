package final_blackjack;

public class Card {
    private final int rank;
    private final int suit;
    String[] suits;
    String[] suitsSymbol;
    String[] ranks;
    int[] value;
    
    public Card(int rank, int suit) {
        this.suitsSymbol = new String[]{"\u2663", "\u2666", "\u2665", "\u2660"};
        this.suits = new String[]{"Clubs", "Diamonds", "Hearts", "Spades"};
        this.ranks = new String[]{null, "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
        this.value = new int[]{0, 11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10};
        this.rank = rank;
        this.suit = suit;
    }
    
    public String getCardName(){
        
        
        String name = ranks[this.rank] + " of " + suits[this.suit];
        return name;
    }
    
    public int getRank(){
        return this.rank;
    }
    
    public int getCardValue(){
        return this.value[this.rank];
    }
    
    public String renderCard(){
        return ranks[this.rank]+suitsSymbol[this.suit];
    }
    
    public String encodeCard() {
    return "" + this.rank + "|" + this.suit;
    }

    public static Card decodeCard(String cardStr) {
    String[] parts = cardStr.split("\\|");
    return new Card(Integer.parseInt(parts[0]), Integer.parseInt(parts[1]));
}
}
