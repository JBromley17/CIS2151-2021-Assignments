package final_blackjack;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

public final class Game {
    
    public int playerNum;
    private ArrayList<Player> playerList;
    private Shoe dealerShoe;
    private int potValue;
    
    
    public boolean roundComplete = false;
    public String roundWinner;
    
    public Game(int extraAI) {
        //Number of extraAI, including dealer, is 2 to 5.  Dealer, player, 0-3 AI extraAI
        playerNum = extraAI + 2;
        this.resetTable();
        
    }
    
    private Game(ArrayList<Player> playerList, Shoe dealerShoe, int potValue, boolean roundComplete, String roundWinner){
        this.playerNum = playerList.size();
        this.playerList = playerList;
        this.dealerShoe = dealerShoe;
        this.potValue = potValue;
        this.roundComplete = roundComplete;
        this.roundWinner = roundWinner;
    }
    
    public void resetTable (){
        
        this.dealerShoe = new Shoe();
        this.playerList = new ArrayList<>();
        for(int players = 0; players<this.playerNum; players++){
            this.playerList.add(new Player(players));
        }
        this.potValue = 0;
    }
    
    //Will only be called when player selects start.  At start of a game, Hit And Stand need to be disabled
    //Player can only make Bet, Save, Restart or Quit
    //TO DO: Set playerHand to Empty
    //Loop through playerlist and set each to not have cards.  Set Boolean finishedRound = false;
    //Set this.roundComplete = False.
    public boolean beginRound(int bet){
        this.roundWinner = null;
        this.potValue = 0;
        if(this.playerList.get(1).makeBet(bet)){
            this.potValue += bet;
        }
        else {
            return false;
        }
        if(this.playerNum>2){
            for(int x = 2; x<this.playerNum; x++){
            if(!this.playerList.get(x).eliminated){
                    this.potValue+=this.playerList.get(x).makeRandomBet();
            }
        }
        
            
                
            //get bets from each player.  cannot be more than current money amount
            
        }
        for(int x = 0; x<(this.playerList.size())*2; x++){
            Card card = this.dealerShoe.Deal();
                this.playerList.get(x%this.playerList.size()).addCard(card);
                
            //get bets from each player.  cannot be more than current money amount
            //Make sure to enable Hit and Stand at end.
        }
        return true;
    }
    
    public void playAITurn() {
        for(int x = 2; x<this.playerNum; x++){
            if(!this.playerList.get(x).eliminated){
                if(this.playerList.get(x).getPlayerHandValue()<17) {
                    Card card = this.dealerShoe.Deal();
                    this.playerList.get(x).hit(card);
                }
                else {
                    this.playerList.get(x).stand();
                }
            }
            else {
                this.playerList.get(x).finishedRound = true;
            }
        }
    }

    public void Hit (){
        Card card = this.dealerShoe.Deal();
        this.playerList.get(1).hit(card);
        if(this.playerNum>2){
            this.playAITurn();
        }
        this.finishGame();
        //maybe return String
        //hit needs to add a card to the active players hand
        //it needs to calculate if there is a bust
        //needs to return information about bust
        }
    
    public void Stand (){
        this.playerList.get(1).stand();
        if(this.playerNum>2){
            this.playAITurn();
        }
        this.finishGame();
        
        //maybe return String
        //Stand needs to calculate value of players hand and return value to UI
    }
    
    
    public void doubleDown (){
        if(this.playerList.get(1).canDoubleDown()){
            Card card = this.dealerShoe.Deal();
            this.potValue += this.playerList.get(1).doubleDown(card);
        }
        if(this.playerNum>2){
            this.playAITurn();
        }
        this.finishGame();
    }
    //public ArrayList<Card> getCurrentPlayerHand(){
    
    public boolean checkForRemainingPlayers() {
        boolean z = false;
        for(int x = 1; x < this.playerNum; x++){
            if(!this.playerList.get(x).finishedRound){
                z = true;
            }
            
        }
        return z;
    }
    
    public void finishGame() {
        if(this.playerList.get(1).finishedRound){
            while(this.checkForRemainingPlayers()){
                this.playAITurn();
            }
            this.roundComplete = true;
            this.dealerPlay();
            this.scoreGame();
        }
    }
    
    public void dealerPlay() {
        while(!this.playerList.get(0).finishedRound){
            if(this.playerList.get(0).getPlayerHandValue()<17) {
                Card card = this.dealerShoe.Deal();
                this.playerList.get(0).hit(card);
            }
            else {
                this.playerList.get(0).stand();
            }
        }
    }
    
    public String scoreGame() {
        int topScoringPlayer = 0;
        int topScore = 0;
        String winner = "dealer";
        int dealerScore = this.playerList.get(0).getPlayerHandValue();
        if(dealerScore > 21){
            dealerScore = 0;
        }
        for(int x = 1; x < this.playerNum; x++){
            int score = this.playerList.get(x).getPlayerHandValue();
            if(score<=21 && score>topScore){
                topScore = score; 
                topScoringPlayer = x;
            }
        }
        if(topScore>dealerScore){
            this.playerList.get(topScoringPlayer).addWinnings(this.potValue);
            this.potValue = 0;
            winner = this.playerList.get(topScoringPlayer).name;
        }
        this.roundWinner = winner;
        return winner;
    }
    
    public String getPlayerHand(int playerId){
        if(playerId<this.playerNum){
        return this.playerList.get(playerId).renderPlayerHand();
        
        }
        else {
            return null;
        }
    }
    
    //}
    
    public boolean isHumanPlayerOut(){
        return this.playerList.get(1).eliminated;
    }
    
    public int getPlayerMoney(int playerId){
        if(playerId<this.playerNum){
        return this.playerList.get(playerId).money;
        
        }
        else {
            return 0;
        }
    }
    
    public String getPlayerStatus(int playerId){
        if(playerId<this.playerNum){
        return this.playerList.get(playerId).getPlayerStatus();
        
        }
        else {
            return "BUST";
        }
    }
    
    
    public String getPotValue(){
        return Integer.toString(potValue);
    }
    
            //make display for AI money and Player money
            //make functions to get dealer hand, and if dealer is out
            //make functions to get AI hand, and if AI player is out
            //Display pot value
            //Display money that all players have
    
    public void startNextRound(){
        this.roundComplete = false;
        for(int players = 0; players<this.playerNum; players++){
            this.playerList.get(players).resetPlayer();
        }
    }
    
    public void save(){
//        public int playerNum;
//        private ArrayList<Player> playerList;
//        private Shoe dealerShoe;
//        private int potValue;
//        public boolean roundComplete = false;
//        public String roundWinner;  
//        
//        public int money = 100;
//        public int playerNum;
//        public String name;
//        private ArrayList<Card> cards = new ArrayList<Card>();
//        public int bet;
//        public boolean eliminated = false;
//        public boolean finishedRound = false;

 Properties prop = new Properties();
    prop.setProperty("player_count", Integer.toString(this.playerNum));
    for (int pNum = 0; pNum < this.playerNum; pNum++){
        this.playerList.get(pNum).addToProperties(prop, pNum);
        }
    String shoeStr = String.join(",", this.dealerShoe.listCardsInShoe().stream().map((c) -> c.encodeCard()).collect(Collectors.toList()));
    prop.setProperty("shoe", shoeStr);
    prop.setProperty("potValue", Integer.toString(this.potValue));
    prop.setProperty("round Complete", Boolean.toString(this.roundComplete));
    if(this.roundWinner != null){
        prop.setProperty("Round Winner", this.roundWinner);
    }
    try(OutputStream output = new FileOutputStream("SaveGame.properties")){
       prop.store(output, null); 
    }catch(IOException e){
        e.printStackTrace();
    }
    
    }
    
    public static Game load() {
    Properties prop = new Properties();
    try(InputStream input = new FileInputStream("SaveGame.properties")){
       prop.load(input);
    }catch(IOException e){
        e.printStackTrace();
    }
    int playerCount = Integer.parseInt(prop.getProperty("player_count"));
    ArrayList<Player> players = new ArrayList<Player>();
    for (int i = 0; i < playerCount; i++) {
        Player player = Player.fromProperties(prop, i);
        players.add(player);
    }
    String shoeStr = prop.getProperty("shoe");
    List<Card> shoeCards = Arrays.asList(shoeStr.split(",")).stream().map((s) -> Card.decodeCard(s)).collect(Collectors.toList());
    Shoe shoe = new Shoe(new ArrayList<Card>(shoeCards));
    int potValue = Integer.parseInt(prop.getProperty("potValue"));
    boolean roundComplete = Boolean.parseBoolean(prop.getProperty("round Complete"));
    String roundWinner = prop.getProperty("Round Winner");
    return new Game(players, shoe, potValue, roundComplete, roundWinner);
}
   
}



