
package final_blackjack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Properties;
import java.util.concurrent.ThreadLocalRandom;
import java.util.stream.Collectors;
import java.util.List;

public class Player {
    
    public int money = 100;
    public int playerNum;
    public String name;
    private ArrayList<Card> cards = new ArrayList<Card>();
    public int bet;
    public boolean eliminated = false;
    
    
    public boolean finishedRound = false;
    
    public Player(int playerNum) {
        this.name = "jimmy" + playerNum;
        this.playerNum = playerNum;
}
    
    public Player(int playerNum, String name) {
        this.name = name;
        this.playerNum = playerNum;
    }
    public void addCard(Card card){
        this.cards.add(card);
        if(this.getPlayerHandValue()>21){
            this.finishedRound = true;
        }
    }
    
    public String renderPlayerHand(){
        String playerHand = "";
        if(cards.size()>0){
            for(int x = 0; x<cards.size(); x++){
                playerHand+=cards.get(x).renderCard()+", ";
            }
            return playerHand.substring(0, playerHand.length()-2);
        }
        return playerHand;
    }
        
    public ArrayList<Card> getPlayerHand(){
        return this.cards;
    }
    public int getPlayerHandSize(){
        return this.cards.size();
    }
    public int getPlayerHandValue(){
        int handValue = 0;
        int aceCount = 0;
        for(int x = 0; x<this.cards.size(); x++){
            int cardValue = this.cards.get(x).getCardValue();
            handValue+=cardValue;
            if(cardValue == 11){
                aceCount++;
            }
        }
        if(handValue>21 && aceCount > 0){
            while(aceCount > 0 && handValue > 21){
                handValue -= 10;
                aceCount -= 1;
            }
        }
        //System.out.println("Player name: " + this.name + "handValue " + handValue);
        return handValue;
    }
    public int getPlayerMoney(){
        return this.money;
    }
    
    public String getPlayerStatus(){
        if(this.eliminated){
            return "Eliminated";
        }
        else if(!this.finishedRound){
            return "";
        }
        else if(this.getPlayerHandValue()>21){
            return "BUST!";
        
        }
        else {
            return "STOOD";
        }
    }
    
    public boolean makeBet(int amt){
        if(amt<=this.money && amt>0){
            this.money -=amt;
            this.bet = amt;
            return true;
        }
        else{
            return false;
        }
    }
    public int makeRandomBet(){
        int bet = 1;
        
        if(this.money>1){
            bet = ThreadLocalRandom.current().nextInt(1, this.money);
        }
        System.out.println(this.name + " Bet amount:" + bet);
        this.makeBet(bet);
        return bet;
    }
    
    public void hit(Card card) {
        this.addCard(card);
    }
    
    public void stand() {
        this.finishedRound = true;
    }
    
    public int doubleDown(Card card) {
       this.money -= this.bet;
       this.addCard(card);
       this.finishedRound = true;
       return this.bet;
        
    }
    
    public boolean canDoubleDown() {
        if(this.money>this.bet) {
            return true;
        }
        else {
            return false;
        }
        
    }
    
    public void addWinnings(int amt) {
        this.money += amt;
    }
    
    public void resetPlayer(){
        this.cards = new ArrayList<Card>();
        this.bet =0;
        this.finishedRound = false;
        if(this.money <=0){
            this.eliminated = true;
            System.out.println(this.name + " was Eliminated.");
        }
    }
    
    public void addToProperties(Properties prop, int num) {
    String handStr = String.join(",", this.cards.stream().map((c) -> c.encodeCard()).collect(Collectors.toList()));
    prop.setProperty("Player." + num + ".name", this.name);
    prop.setProperty("Player." + num + ".hand", handStr);
    prop.setProperty("Player." + num + ".money", Integer.toString(this.money));
    prop.setProperty("Player." + num + ".bet", Integer.toString(this.bet));
    prop.setProperty("Player." + num + ".eliminated", Boolean.toString(this.eliminated));
    prop.setProperty("Player." + num + ".finished Round", Boolean.toString(this.finishedRound));
    }

    public static Player fromProperties(Properties prop, int num) {
        String name = prop.getProperty("Player." + num + ".name");
        String handStr = prop.getProperty("Player." + num + ".hand");
        List<Card> hand = new ArrayList<Card>(); 
        if(!handStr.equals("")){
            hand = Arrays.asList(handStr.split(",")).stream().map((s) -> Card.decodeCard(s)).collect(Collectors.toList());
        }
        int money = Integer.parseInt(prop.getProperty("Player." + num + ".money"));
        int bet = Integer.parseInt(prop.getProperty("Player." + num + ".bet"));
        boolean eliminated = Boolean.parseBoolean(prop.getProperty("Player." + num + ".eliminated"));
        boolean finishedRound = Boolean.parseBoolean(prop.getProperty("Player." + num + ".finished Round"));
        Player player = new Player(num, name);
        for(Card card: hand){
            player.addCard(card);
        }
        player.money = money;
        player.bet = bet;
        player.eliminated = eliminated;
        player.finishedRound = finishedRound;
        return player;
    }
    
    
}
