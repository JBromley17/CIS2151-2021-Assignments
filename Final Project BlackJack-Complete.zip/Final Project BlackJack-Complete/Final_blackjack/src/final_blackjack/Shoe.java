package final_blackjack;

import java.util.ArrayList;
import java.util.Collections;

public class Shoe {
    
    private ArrayList<Card> Shoe;
    public boolean reshuffle = false;
    public int cardCount;
    
    public Shoe() {
        this.Shoe = new ArrayList<Card>(); 
        this.MakeShoe();
    }
    
    public Shoe(ArrayList<Card> cards){
        this.Shoe = cards;
    }
    
    public void MakeShoe() {
        for(int decks = 0; decks<6; decks++){
            Deck deckies = new Deck();
            this.Shoe.addAll(deckies.getCards());
        }
        this.cardCount = 0;
        this.Shuffle();
    }
    
    public void Shuffle() {
        Collections.shuffle(this.Shoe);
    }
    
    public Card Deal() {
       Card card = this.Shoe.get(0);
       int cardRank = card.getRank();
       this.Shoe.remove(0);
       if(cardRank>=2 && cardRank <=6){
           this.cardCount+=1;
       }
       else if(cardRank>=7 && cardRank <=9){
           this.cardCount+=0;
       }
       else {
           this.cardCount-=1;
       }
       
       if(this.Shoe.size()<30){
           this.reshuffle = true;
       }
       return card;
    }
    
    public int remainingCards() {
        return this.Shoe.size();
    }
    
    public ArrayList<Card> listCardsInShoe(){
        return Shoe;
    }
    
}




