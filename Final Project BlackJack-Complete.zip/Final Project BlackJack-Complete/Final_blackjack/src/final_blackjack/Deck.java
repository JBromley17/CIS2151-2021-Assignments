
package final_blackjack;

import java.util.ArrayList;
import java.util.Collections;

public class Deck {
    
    private ArrayList<Card> cards;
    
    
    public Deck() {
        this.makeDeck();
        }
    
    public void makeDeck() {
        this.cards = new ArrayList<Card>();
         for (int suit = 0; suit<=3; suit++){
             for (int rank = 1; rank <=13; rank++){
                 this.cards.add(new Card(rank, suit));
            }     
        }
    }
    
    public void Shuffle() {
        Collections.shuffle(this.cards);
    }
    
    public Card Deal() {
       Card card = this.cards.get(0);
       this.cards.remove(0);
       return card;
    }
    
    public ArrayList<Card> getCards() {
        return this.cards;
        
    }
    
}


