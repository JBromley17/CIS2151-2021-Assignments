
package final_blackjack;


public class Main implements Runnable {

    gameScreen blackJackgui = new gameScreen();
    
    public static void main(String[] args) {
        new Thread( new Main()).start();
//        int numOfAI = 3;
//        //Need to get this int from UI, Player entering them.
//        Game blackJack = new Game(numOfAI);
//        int bet = 10;
//        //Need to get this int from UI, Player entering them.
//        //blackJack.beginRound will return false if the bet amount is invalid.
//        blackJack.beginRound(bet);
//        while(!blackJack.roundComplete){
//            //Call these functions depending on what button the user Clicks
//            blackJack.Hit();
//            blackJack.Stand();
//            blackJack.doubleDown();
//
//        }
//        blackJack.dealerPlay();
//        String winningPlayer = blackJack.scoreGame();
    }
    
    

    @Override
    public void run() {
        
    }
    
}
